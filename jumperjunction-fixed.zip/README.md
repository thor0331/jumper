# JumperJunction

JumperJunction is a beginner-friendly hardware project website for Arduino, ESP32, ESP8266, Raspberry Pi, and similar boards. It includes a public project browser, per-project build pages, and an admin workflow backed by a Cloudflare Worker and a static `projects.json` archive.

## Features

- Beginner-focused project cards and guided project pages
- Per-project wiring, code, steps, gallery images, creator credits, and YouTube source links
- Code and image downloads named like `jumperjunction_<project>`
- Anonymous page-view counting with browser session protection so refresh in the same tab does not inflate views
- Primary admin publishing flow
- Sub-developer accounts verified through Cloudflare so contributors can publish their own projects without seeing backend secrets

## Files

- `index.html`: public homepage
- `project.html`: individual project page
- `admin.html`: admin and contributor panel
- `projects.json`: monthly archive plus site metadata
- `cloudflare-worker/worker.js`: backend API for live DB storage, page views, rate limiting, and developer auth

## Cloudflare Setup

1. Create a Worker and deploy `cloudflare-worker/worker.js`
2. Add secrets:
   - `GITHUB_TOKEN`
   - `ADMIN_API_KEY`
3. Add vars:
   - `GITHUB_OWNER=prashanthg05`
   - `GITHUB_REPO=JumperJunction`
   - `GITHUB_BRANCH=main`
   - `ALLOWED_ORIGIN=https://prashanthg05.github.io`
4. Bind a KV namespace as `VISITOR_STATS`

## GitHub Token Permissions

Use a fine-grained personal access token with:

- repository access: only `JumperJunction`
- repository permission: `Contents: Read and write`

## Admin Flow

- Primary admin unlocks the panel locally with the device password
- Backend config stores the Cloudflare worker URL and admin key locally on that device
- Developers sign in with Cloudflare-backed credentials created by the primary admin
- Developers can only create, edit, and delete their own projects

## Visit Counter

- New browsers get a local `jumper-junction_has_visited` flag
- First-time browsers increment the Cloudflare pending counter
- Recommended archive workflow:
- 1. Publish current work to the live DB.
- 2. Export the live DB from admin.
- 3. Merge that JSON into `projects.json`.
- 4. Deploy the updated archive.
- 5. Remove older live DB items only after the archive is safely deployed if you want to reduce KV usage.

## Usage Policy

- JumperJunction is intended to stay 100% free for learners.
- The site code and curated content are shared for learning, contribution, and open community access.
- Community project content, creator credit, linked videos, and license text must be respected as provided by the original creator.
- Do not commercially resell project content from JumperJunction without checking the creator's project license and receiving permission when needed.

## Notes

- Keep secrets only in Cloudflare, never in GitHub
- The repo can stay public as long as tokens and admin keys are never committed
